package Plugins::MobileTranscode::Plugin;

sub initPlugin {}

1;
